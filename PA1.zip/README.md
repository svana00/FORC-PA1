# PA1 - Group 10

## Version

We implemented version B without the bonus.

## Compiling and running

Run g++ -o wav_example wav_example.cpp on mac to compile.
Then run with the command ./wav_example